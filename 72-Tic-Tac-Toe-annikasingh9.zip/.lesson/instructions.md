# **TicTacToe**

For this assignment you will be creating a TicTacToe game. 

## create_board()
- This function takes in not arguments. There is no need to put a parameter in the function's parenthesis.
- Use a 2D-list to represent the board.
	-The 2d list should contain 3 inner lists.
  	- Each of the inner lists should contain items which will represent the individual cells of the TicTacToe board.
- The function should return the 2d-list

## place_mark(board, player)
- This function does:
	- Asks the player where he/she wants to place their mark.
	  - Player needs to indicate which row(list_index) and column(item_index) he/she want to place their mark.
	    - Before place the player's mark at the row and column value, the progam needs to check to see that the cell isn't already occupied. If the cell is occupied, the game can ask the player to guess again.
      - Check that the row and column values fall between 0 and 2.
    - Assign the player's mark to the specified cell.
  - Return board


## display_board(board):
- This function prints the board to the console.
- This function will used nested for loop to display the items in the first list on the top row, the items in the second list in the middle row, and the items in the third list in the bottom row.
- Hint: print(item, end = "")

## is_winner(board):
- The function determines if either player has won. Players can win with three in a row in the horizontal, vertical or diagonal.
- If a player wins, the function will print a message stating who wins.
- This function returns True if someone has one and False if no one has won.

